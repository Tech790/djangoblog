from django.contrib import admin
from .models import Categorie,Post,Comment,Contact
# Register your models here.

@admin.register(Categorie)
class CategorieAdmin(admin.ModelAdmin):
	list_display = ['name']


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
	list_display = ['title']


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
	list_display = ['name']


@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
	list_display = ['name']