from django.shortcuts import render
from .models import Categorie,Post,Comment,Contact
import datetime
from django.http import JsonResponse
from django.contrib import messages
from django.core.paginator import Paginator,PageNotAnInteger,EmptyPage
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import get_object_or_404


# Create your views here.
def home(request):
	posts = Post.objects.all().order_by('-id')
	# It will return previous week date
	month_ago = datetime.date.today() - datetime.timedelta(days=30)
	recent = Post.objects.filter(add_time__gte=month_ago).order_by('-id')
	categories = Categorie.objects.all()
	return render(request,'index.html',
		{'posts':posts,'recents':recent[:3],
		'categories':categories})


def about(request):
	return render(request,'about.html')


def contact(request):
	if request.method == 'POST':
		name = request.POST['name']
		email = request.POST['email']
		subject = request.POST['subject']
		message = request.POST['message']

		user = Contact(
			name=name,email=email,subject=subject,
			message=message
			).save()
	return render(request,'contact.html')



def blog(request):
	posts = Post.objects.all().order_by('-id')
	all_post = Paginator(posts,6)
	categories = Categorie.objects.all()
	month_ago = datetime.date.today() - datetime.timedelta(days=30)
	recent = Post.objects.filter(add_time__gte=month_ago).order_by('-id')
	comments = Comment.objects.all()
	page = request.GET.get('page')
	try:
		posts = all_post.page(page)
	except PageNotAnInteger:
		posts = all_post.page(1)
	except EmptyPage:
		posts = all_post.page(all_post.num_pages)
	return render(request,'blog.html',
		{'posts':posts,'categories':categories,
		'recents':recent})

def post_details(request,id):
	if request.method == 'POST':
		name = request.POST['name']
		email = request.POST['email']
		message = request.POST['message']
		comt = Comment(name=name,email=email,
			comment=message)
		comt.save()
	
	post = Post.objects.get(pk=id)
	week_ago = datetime.date.today() - datetime.timedelta(days=7)
	recent = Post.objects.filter(add_time__gte=week_ago).order_by('-id')
	categories = Categorie.objects.all()
	posts = Post.objects.all()
	post.read += 1
	post.save()
	comments = Comment.objects.filter(on_post=post)
	return render(request,'post-details.html',
		{'post':post,'recents':recent[:3],
		'categories':categories,'posts':posts,
		'comments':comments})


def show_category(request,id):
	cat = Categorie.objects.get(pk=id)
	posts = Post.objects.filter(cat=cat)
	categories = Categorie.objects.all()
	month_ago = datetime.date.today() - datetime.timedelta(days=30)
	recent = Post.objects.filter(add_time__gte=month_ago).order_by('-id')
	return render(request,'index.html',
		{'posts':posts,'categories':categories,'recents':recent})




	


